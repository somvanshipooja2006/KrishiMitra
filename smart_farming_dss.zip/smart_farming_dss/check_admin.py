import database

print("CROPS:")
print(database.execute_query("SELECT COUNT(*) AS c FROM crops", fetch='one'))

print("ADMIN:")
print(database.execute_query("SELECT COUNT(*) AS c FROM admin", fetch='one'))