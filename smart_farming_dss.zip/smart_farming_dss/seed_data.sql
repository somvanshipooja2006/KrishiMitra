USE krishimitra_db;

-- Clear existing data if any (in correct order of dependencies)
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE recommendations;
TRUNCATE TABLE fertilizers;
TRUNCATE TABLE seed_varieties;
TRUNCATE TABLE crops;
TRUNCATE TABLE admin;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Seed default admin (username: admin, password: admin123 - hashed using Werkzeug scrypt default)
INSERT INTO admin (username, password) VALUES 
('admin', 'scrypt:32768:8:1$fjxqStk2vBl6IIis$dfc0f3ca118c64b59ce3117b63418724d550c8f06f21aaeda133ce1e4d687bb0ad889159d012824f936f1ca6cf62bd5a2a8c43aea81754e34b9ee8fd8998b23f');

-- 2. Seed crops
INSERT INTO crops (id, crop_name, season, soil_type, crop_duration, crop_description, crop_image) VALUES
(1, 'Rice', 'Kharif', 'Clayey', '120-150 Days', 'Rice is a staple food crop requiring high moisture, standing water, and heavy clayey or loamy soils.', 'rice.jpg'),
(2, 'Wheat', 'Rabi', 'Loamy', '110-140 Days', 'Wheat is a temperate crop grown in winter, requiring moderate moisture and fertile loamy soils.', 'wheat.jpg'),
(3, 'Maize', 'Kharif/Summer', 'Loamy', '90-110 Days', 'Maize (Corn) is a versatile crop grown under various climatic conditions, preferring well-drained fertile soils.', 'maize.jpg'),
(4, 'Cotton', 'Kharif', 'Black', '150-180 Days', 'Cotton is a cash crop requiring high temperature, moderate rainfall, and deep black clayey soils (Regur).', 'cotton.jpg'),
(5, 'Soybean', 'Kharif', 'Loamy/Clayey', '90-120 Days', 'Soybean is a major oilseed and protein-rich legume crop requiring warm temperatures and well-drained soils.', 'soybean.jpg'),
(6, 'Pigeon Pea (Tur)', 'Kharif', 'Loamy/Sandy', '150-180 Days', 'Pigeon Pea (Tur) is an important pulse crop that is highly drought-resistant and improves soil nitrogen levels.', 'pigeonpea.jpg'),
(7, 'Chickpea', 'Rabi', 'Loamy', '100-120 Days', 'Chickpea (Gram) is a cool-season pulse crop grown with low moisture, utilizing residual soil moisture.', 'chickpea.jpg'),
(8, 'Groundnut', 'Kharif', 'Sandy/Loamy', '100-130 Days', 'Groundnut is an oilseed crop that grows best in light, loose sandy-loamy soils that allow pods to penetrate.', 'groundnut.jpg'),
(9, 'Mustard', 'Rabi', 'Sandy-Loamy', '110-130 Days', 'Mustard is a cool-season oilseed crop requiring cool temperatures and moderate soil moisture.', 'mustard.jpg'),
(10, 'Sunflower', 'Rabi/Kharif', 'Loamy', '90-100 Days', 'Sunflower is a drought-tolerant crop grown for edible oil, adaptable to a wide range of soil conditions.', 'sunflower.jpg'),
(11, 'Bajra', 'Kharif', 'Sandy', '80-90 Days', 'Bajra (Pearl Millet) is a highly drought-resistant food grain grown in dry climates with sandy soils.', 'bajra.jpg'),
(12, 'Jowar', 'Kharif/Rabi', 'Clayey/Loamy', '100-120 Days', 'Jowar (Sorghum) is a dual-purpose grain and fodder crop thriving in warm and dry areas.', 'jowar.jpg'),
(13, 'Barley', 'Rabi', 'Loamy', '110-130 Days', 'Barley is a cereal grain crop that is tolerant to salinity and grows well in semi-arid environments.', 'barley.jpg'),
(14, 'Sugarcane', 'Annual', 'Loamy/Clayey', '300-360 Days', 'Sugarcane is a long-duration cash crop requiring heavy water inputs, hot climate, and organic-rich soils.', 'sugarcane.jpg'),
(15, 'Onion', 'Rabi/Kharif', 'Sandy-Loamy', '120-150 Days', 'Onion is a shallow-rooted vegetable crop requiring well-drained fertile soils and balanced nutrients.', 'onion.jpg'),
(16, 'Potato', 'Rabi', 'Sandy-Loamy', '90-120 Days', 'Potato is a tuber crop requiring cool nights, moderate daytime temperatures, and loose, porous soils.', 'potato.jpg'),
(17, 'Tomato', 'Year-round', 'Loamy', '110-130 Days', 'Tomato is a widely grown vegetable crop that prefers warm weather, ample sunlight, and well-structured soils.', 'tomato.jpg'),
(18, 'Brinjal', 'Year-round', 'Loamy', '110-140 Days', 'Brinjal (Eggplant) is a hardy warm-season vegetable crop adaptable to varied soils but prefers loamy soil.', 'brinjal.jpg'),
(19, 'Chilli', 'Kharif/Rabi', 'Loamy', '120-150 Days', 'Chilli is a spice crop requiring warm temperatures, moderate rainfall, and well-drained sandy-clay soils.', 'chilli.jpg'),
(20, 'Garlic', 'Rabi', 'Sandy-Loamy', '130-150 Days', 'Garlic is a bulb crop requiring cool weather during growth and warm dry conditions for maturity.', 'garlic.jpg'),
(21, 'Turmeric', 'Kharif', 'Loamy/Sandy', '240-270 Days', 'Turmeric is a tropical herb cultivated for its rhizomes, requiring hot, humid climates and rich soils.', 'turmeric.jpg'),
(22, 'Ginger', 'Kharif', 'Sandy-Loamy', '240-270 Days', 'Ginger is a spice crop grown underground, requiring warmth, high humidity, shade, and rich organic soil.', 'ginger.jpg'),
(23, 'Coffee', 'Perennial', 'Loamy', 'Annual Harvest', 'Coffee is a plantation beverage crop grown on hillsides under shade, requiring high humidity and acidic soil.', 'coffee.jpg'),
(24, 'Tea', 'Perennial', 'Loamy', 'Annual Harvest', 'Tea is a plantation crop grown on sloped terrains, requiring high distributed rainfall and acidic soils.', 'tea.jpg'),
(25, 'Jute', 'Kharif', 'Alluvial/Sandy', '120-150 Days', 'Jute is a natural fiber crop requiring high heat, heavy rainfall, standing water, and fertile alluvial soil.', 'jute.jpg');

-- 3. Seed Seed Varieties
INSERT INTO seed_varieties (crop_id, variety_name, sowing_period, expected_yield, seed_quantity) VALUES
(1, 'IR-64, Jaya, MTU-1010', 'June - July', '5.5 - 6.5 Tons/Hectare', '40-50 kg/Hectare'),
(2, 'HD-2967, Lok-1, GW-322', 'November - December', '4.5 - 5.5 Tons/Hectare', '100 kg/Hectare'),
(3, 'HQPM-1, Pioneer 30G37, Dekalb', 'June - July', '6.0 - 7.5 Tons/Hectare', '20 kg/Hectare'),
(4, 'Bt Cotton (Kanak, Bunny), RCH-2', 'May - June', '2.0 - 2.5 Tons/Hectare', '2.5 - 3.0 kg/Hectare'),
(5, 'JS-335, JS-95-60, MAUS-71', 'June - July', '2.0 - 3.0 Tons/Hectare', '75 kg/Hectare'),
(6, 'ICPL-87119 (Asha), BDN-711, Maruti', 'June - July', '1.5 - 2.0 Tons/Hectare', '15 kg/Hectare'),
(7, 'Vijay, Digvijay, JAKI-9218', 'October - November', '1.8 - 2.2 Tons/Hectare', '75-80 kg/Hectare'),
(8, 'JL-24, TAG-24, GG-20', 'June - July', '2.0 - 2.5 Tons/Hectare', '100-120 kg/Hectare'),
(9, 'Pusa Bold, Varuna, Kranti', 'October - November', '1.5 - 2.0 Tons/Hectare', '5 kg/Hectare'),
(10, 'KBSH-1, LSFH-171, DRSH-1', 'October - November', '1.8 - 2.2 Tons/Hectare', '8-10 kg/Hectare'),
(11, 'ICTP-8203, HHB-67, Pioneer 86M32', 'July - August', '1.5 - 2.0 Tons/Hectare', '4-5 kg/Hectare'),
(12, 'CSH-14, CSH-16, Maldandi (M-35-1)', 'July - August / Oct', '2.0 - 3.0 Tons/Hectare', '10-12 kg/Hectare'),
(13, 'RD-2035, RD-2552, BH-75', 'November - December', '3.5 - 4.5 Tons/Hectare', '100 kg/Hectare'),
(14, 'Co-86032, Co-0238, CoM-0265', 'Jan - Feb / Oct - Nov', '80 - 100 Tons/Hectare', '6-8 Tons of Setts/Hectare'),
(15, 'N-2-4-1, Bhima Super, Arka Kalyan', 'October - November', '25 - 30 Tons/Hectare', '8-10 kg/Hectare (Nursery)'),
(16, 'Kufri Jyoti, Kufri Bahar, Kufri Pukhraj', 'October - November', '20 - 25 Tons/Hectare', '1.5 - 2.0 Tons of Tubers/Hectare'),
(17, 'Arka Rakshak, Vaishnavi, Abhinav', 'October / Jan / June', '40 - 50 Tons/Hectare', '150-200 g/Hectare (Nursery)'),
(18, 'Arka Keshav, Pusa Purple Round, Manjari', 'June / October', '25 - 35 Tons/Hectare', '300-400 g/Hectare (Nursery)'),
(19, 'Jwala, G-4, Tejaswini', 'June - July / Oct', '2.0 - 2.5 Tons/Hectare (Dry)', '1.0 kg/Hectare'),
(20, 'G-282, Yamuna Safed, Phule Baswant', 'October - November', '10 - 12 Tons/Hectare', '500-600 kg of Cloves/Hectare'),
(21, 'Selam, IISR Pragati, Krishna', 'May - June', '20 - 25 Tons/Hectare (Fresh)', '2.0 - 2.5 Tons of Rhizomes/Hect'),
(22, 'Mahima, Varada, Suprabha', 'May - June', '15 - 20 Tons/Hectare (Fresh)', '1.5 - 1.8 Tons of Rhizomes/Hect'),
(23, 'S.795, Cauvery, Selection 9', 'June - Sept (planting)', '1.0 - 1.5 Tons/Hectare', 'Nursery raised seedlings'),
(24, 'UPASI-3, Assam Hybrid, TV-1', 'June - October', '2.0 - 2.5 Tons/Hectare', 'Nursery raised clones'),
(25, 'JRC-321, JRO-524, JRO-8432', 'March - April', '2.5 - 3.0 Tons/Hectare', '6-8 kg/Hectare');

-- 4. Seed Fertilizers
INSERT INTO fertilizers (crop_id, fertilizer_name, quantity, application_time) VALUES
(1, 'Urea, Single Super Phosphate (SSP), Muriate of Potash (MOP)', '120kg N, 60kg P, 40kg K per Hectare', 'SSP & MOP at sowing; Urea split in 3 doses (basal, tillering, panicle initiation)'),
(2, 'DAP, Urea, Muriate of Potash (MOP)', '120kg N, 60kg P, 40kg K per Hectare', 'Full DAP & MOP at sowing; Urea in 2 splits with first and second irrigations'),
(3, 'NPK Complex (10:26:26), Urea', '100kg N, 50kg P, 50kg K per Hectare', 'Basal dose of NPK complex; Urea split at knee-high and tasseling stages'),
(4, 'Urea, SSP, MOP', '100kg N, 50kg P, 50kg K per Hectare', 'SSP and MOP at basal; Nitrogen split in 3 doses at 30, 60, and 90 days after sowing'),
(5, 'DAP, Muriate of Potash (MOP), Bentonite Sulphur', '30kg N, 80kg P, 40kg K per Hectare', 'All fertilizer as basal dose at the time of sowing'),
(6, 'Urea, SSP, MOP', '25kg N, 50kg P, 25kg K per Hectare', 'Basal application at the time of sowing'),
(7, 'Urea, DAP, MOP', '20kg N, 60kg P, 20kg K per Hectare', 'Basal application at the time of sowing'),
(8, 'Gypsum, SSP, MOP, Urea', '25kg N, 50kg P, 50kg K per Hectare', 'SSP, MOP, and half Urea at sowing; Gypsum at 45 days (flowering stage)'),
(9, 'Urea, SSP, MOP, Ammonium Sulphate', '80kg N, 40kg P, 40kg K per Hectare', 'SSP, MOP, and half Urea at sowing; remaining Urea at 30 days during flowering'),
(10, 'DAP, MOP, Urea', '60kg N, 90kg P, 60kg K per Hectare', 'Basal application of DAP and MOP; Urea split at 30 days'),
(11, 'Urea, SSP, MOP', '80kg N, 40kg P, 40kg K per Hectare', 'Half Urea and full SSP/MOP at basal; remaining Urea at 25-30 days'),
(12, 'Urea, DAP, MOP', '80kg N, 40kg P, 40kg K per Hectare', 'Half Urea and full DAP/MOP at basal; remaining Urea at 30-35 days'),
(13, 'Urea, SSP, MOP', '90kg N, 40kg P, 30kg K per Hectare', 'Full SSP/MOP & half Urea at sowing; remaining Urea with first irrigation'),
(14, 'Urea, Single Super Phosphate, MOP', '250kg N, 115kg P, 115kg K per Hectare', 'SSP & MOP split in 2; Urea split in 4 doses (30, 60, 90, 120 days after planting)'),
(15, 'NPK (15:15:15), Urea, MOP', '100kg N, 50kg P, 50kg K per Hectare', 'Basal dose of NPK complex; Urea splits at 30 and 45 days after transplanting'),
(16, 'Urea, DAP, MOP', '120kg N, 80kg P, 120kg K per Hectare', 'Half Urea and full DAP/MOP at planting; remaining Urea at 30-35 days (earthing up)'),
(17, 'Urea, SSP, MOP', '150kg N, 100kg P, 100kg K per Hectare', 'Full SSP and half MOP at basal; Urea split at 30, 45, and 60 days; rest MOP at 45 days'),
(18, 'Urea, SSP, MOP', '100kg N, 80kg P, 60kg K per Hectare', 'SSP & MOP basal; Urea in 3 splits (basal, 30, and 45 days after transplanting)'),
(19, 'Urea, SSP, MOP', '120kg N, 60kg P, 60kg K per Hectare', 'SSP and MOP basal; Urea split in 3 doses (30, 60, 90 days after transplanting)'),
(20, 'Urea, Single Super Phosphate, MOP', '100kg N, 50kg P, 50kg K per Hectare', 'Full SSP & MOP and half Urea at planting; remaining Urea split at 30 and 45 days'),
(21, 'Urea, SSP, MOP, Micronutrients', '60kg N, 50kg P, 120kg K per Hectare', 'SSP basal; Urea and MOP split in 3 doses at 30, 60, and 90 days after planting'),
(22, 'Urea, SSP, MOP', '75kg N, 50kg P, 50kg K per Hectare', 'SSP basal; Urea and MOP split in 2 doses at 40 and 90 days after planting'),
(23, 'NPK Complex (17:17:17), Compost', '140kg N, 90kg P, 120kg K per Hectare', 'Apply in two split doses (Pre-monsoon and Post-monsoon seasons)'),
(24, 'NPK (10:10:10), Zinc Sulphate', '150kg N, 80kg P, 120kg K per Hectare', 'Apply in 3-4 splits matching harvesting/pruning seasons'),
(25, 'Urea, SSP, MOP', '60kg N, 40kg P, 40kg K per Hectare', 'SSP & MOP basal; Urea split at 4-6 weeks and 8-10 weeks after sowing');
