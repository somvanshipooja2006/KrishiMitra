import mysql.connector

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="newpassword",
    database="krishimitra_db"
)

cursor = conn.cursor()

cursor.execute("SELECT @@datadir")
print("DATADIR:", cursor.fetchone())

cursor.execute("SELECT DATABASE()")
print("DATABASE:", cursor.fetchone())

cursor.close()
conn.close()