import os
import random
from datetime import datetime
# from flask import Flask, render_html, render_template, request, redirect, url_for, session, flash, g, send_file
from flask import Flask, render_template, request, redirect, url_for, session, flash, g, send_file
from werkzeug.security import generate_password_hash, check_password_hash
import requests
import database
import predict
from translations import TRANSLATIONS

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'krishimitra_super_secret_key_12984')

# Initialize DB on start
with app.app_context():
    if os.environ.get('WERZEUG_RUN_MAIN') == 'true' or not app.debug:
        database.setup_database()

# Context Processor for localization
@app.context_processor
def inject_translations():
    lang = session.get('lang', 'en')
    def translate(key, fallback=None):
        return TRANSLATIONS.get(lang, {}).get(key, fallback or key)
    return dict(_t=translate, current_lang=lang)

# Language switch route
@app.route('/set_lang/<lang>')
def set_lang(lang):
    if lang in ['en', 'hi', 'mr']:
        session['lang'] = lang
    return redirect(request.referrer or url_for('index'))

# Helper to check farmer login
def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'farmer_id' not in session:
            flash(TRANSLATIONS.get(session.get('lang', 'en'), {}).get('access_denied', 'Access denied. Please login first.'), 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Helper to check admin login
def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            flash('Admin access required.', 'danger')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

# Weather Helper (OpenWeather API with Simulated Fallback)
def get_weather(city_or_district, state=None):
    api_key = os.environ.get('OPENWEATHER_API_KEY', '')
    if not api_key:
        return get_simulated_weather(city_or_district)
    
    try:
        query = f"{city_or_district},{state},IN" if state else f"{city_or_district},IN"
        url = f"https://api.openweathermap.org/data/2.5/weather?q={query}&units=metric&appid={api_key}"
        res = requests.get(url, timeout=4)
        if res.status_code == 200:
            data = res.json()
            return {
                'temp': data['main']['temp'],
                'humidity': data['main']['humidity'],
                'wind_speed': data['wind']['speed'],
                'condition': data['weather'][0]['main'],
                'description': data['weather'][0]['description'],
                'forecast': 'Rainy Showers Expected' if data['weather'][0]['main'] == 'Rain' else 'Clear Skies Ahead',
                'is_simulated': False
            }
        else:
            return get_simulated_weather(city_or_district)
    except Exception:
        return get_simulated_weather(city_or_district)

def get_simulated_weather(city):
    temp = round(random.uniform(24.0, 37.0), 1)
    humidity = random.randint(50, 85)
    wind_speed = round(random.uniform(2.0, 6.0), 1)
    conditions = ['Sunny', 'Cloudy', 'Overcast', 'Passing Showers', 'Humid']
    condition = random.choice(conditions)
    forecasts = {
        'Sunny': 'Dry and sunny weather expected for the week.',
        'Cloudy': 'Scattered clouds, low probability of showers.',
        'Overcast': 'Overcast skies, potential light rain in evening.',
        'Passing Showers': 'Light intermittent showers likely.',
        'Humid': 'High relative humidity, early morning dew.'
    }
    return {
        'temp': temp,
        'humidity': humidity,
        'wind_speed': wind_speed,
        'condition': condition,
        'description': condition.lower(),
        'forecast': forecasts[condition],
        'is_simulated': True
    }


# ======================================================
# LANDING PAGE & GENERAL ROUTES
# ======================================================
@app.route('/')
def index():
    # Fetch a few crops to display on home screen cards
    try:
        sample_crops = database.execute_query("SELECT * FROM crops LIMIT 6", fetch='all')
    except Exception:
        sample_crops = []
    return render_template('index.html', sample_crops=sample_crops)


# ======================================================
# AUTHENTICATION MODULE
# ======================================================
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form.get('full_name')
        mobile = request.form.get('mobile')
        email = request.form.get('email')
        village = request.form.get('village')
        district = request.form.get('district')
        state = request.form.get('state')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return redirect(url_for('register'))
            
        hashed_password = generate_password_hash(password)
        
        try:
            # Check if mobile or email exists
            exist = database.execute_query(
                "SELECT id FROM farmers WHERE mobile = %s OR email = %s",
                (mobile, email), fetch='one'
            )
            if exist:
                flash('Mobile or Email already registered.', 'danger')
                return redirect(url_for('register'))
            
            database.execute_query(
                """INSERT INTO farmers (full_name, mobile, email, village, district, state, password)
                   VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                (full_name, mobile, email, village, district, state, hashed_password)
            )
            flash(TRANSLATIONS.get(session.get('lang', 'en'), {}).get('reg_success', 'Registration successful!'), 'success')
            return redirect(url_for('login'))
        except Exception as e:
            flash(f"Error during registration: {e}", 'danger')
            
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')  # Can be email or mobile
        password = request.form.get('password')
        
        try:
            user = database.execute_query(
                "SELECT * FROM farmers WHERE email = %s OR mobile = %s",
                (username, username), fetch='one'
            )
            if user and check_password_hash(user['password'], password):
                session['farmer_id'] = user['id']
                session['farmer_name'] = user['full_name']
                session['farmer_email'] = user['email']
                session['farmer_district'] = user['district']
                session['farmer_state'] = user['state']
                flash(TRANSLATIONS.get(session.get('lang', 'en'), {}).get('login_success', 'Login successful!'), 'success')
                return redirect(url_for('farmer_dashboard'))
            else:
                flash(TRANSLATIONS.get(session.get('lang', 'en'), {}).get('login_fail', 'Invalid credentials.'), 'danger')
        except Exception as e:
            flash(f"Database error: {e}", 'danger')
            
    return render_template('login.html')

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'POST':
        email = request.form.get('email')
        mobile = request.form.get('mobile')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        if new_password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return redirect(url_for('reset_password'))
            
        try:
            user = database.execute_query(
                "SELECT id FROM farmers WHERE email = %s AND mobile = %s",
                (email, mobile), fetch='one'
            )
            if user:
                hashed_password = generate_password_hash(new_password)
                database.execute_query(
                    "UPDATE farmers SET password = %s WHERE id = %s",
                    (hashed_password, user['id'])
                )
                flash(TRANSLATIONS.get(session.get('lang', 'en'), {}).get('reset_success', 'Password reset successful!'), 'success')
                return redirect(url_for('login'))
            else:
                flash('Farmer details do not match our records.', 'danger')
        except Exception as e:
            flash(f"Error resetting password: {e}", 'danger')
            
    return render_template('reset_password.html')

@app.route('/logout')
def logout():
    session.pop('farmer_id', None)
    session.pop('farmer_name', None)
    session.pop('farmer_email', None)
    session.pop('farmer_district', None)
    session.pop('farmer_state', None)
    return redirect(url_for('index'))


# ======================================================
# FARMER PANEL MODULES
# ======================================================
@app.route('/dashboard')
@login_required
def farmer_dashboard():
    farmer_id = session['farmer_id']
    district = session.get('farmer_district', 'Mumbai')
    state = session.get('farmer_state', 'Maharashtra')
    
    # Fetch weather
    weather = get_weather(district, state)
    
    try:
        # Fetch profile
        farmer = database.execute_query("SELECT * FROM farmers WHERE id = %s", (farmer_id,), fetch='one')
        # Fetch recent 5 history
        history = database.execute_query(
            "SELECT * FROM recommendations WHERE farmer_id = %s ORDER BY recommendation_date DESC LIMIT 5",
            (farmer_id,), fetch='all'
        )
    except Exception:
        farmer = {}
        history = []
        
    return render_template('farmer_dashboard.html', weather=weather, farmer=farmer, history=history)

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    farmer_id = session['farmer_id']
    if request.method == 'POST':
        full_name = request.form.get('full_name')
        mobile = request.form.get('mobile')
        email = request.form.get('email')
        village = request.form.get('village')
        district = request.form.get('district')
        state = request.form.get('state')
        
        try:
            # Check unique constraints
            dup = database.execute_query(
                "SELECT id FROM farmers WHERE (mobile = %s OR email = %s) AND id != %s",
                (mobile, email, farmer_id), fetch='one'
            )
            if dup:
                flash('Mobile or Email already in use by another user.', 'danger')
            else:
                database.execute_query(
                    """UPDATE farmers SET full_name = %s, mobile = %s, email = %s, village = %s, district = %s, state = %s
                       WHERE id = %s""",
                    (full_name, mobile, email, village, district, state, farmer_id)
                )
                session['farmer_name'] = full_name
                session['farmer_district'] = district
                session['farmer_state'] = state
                flash(TRANSLATIONS.get(session.get('lang', 'en'), {}).get('profile_update_success', 'Profile updated!'), 'success')
                return redirect(url_for('profile'))
        except Exception as e:
            flash(f"Update error: {e}", 'danger')

    try:
        farmer = database.execute_query("SELECT * FROM farmers WHERE id = %s", (farmer_id,), fetch='one')
    except Exception:
        farmer = {}
        
    return render_template('profile.html', farmer=farmer)

@app.route('/recommend', methods=['GET', 'POST'])
@login_required
def recommend():
    if request.method == 'POST':
        n = float(request.form.get('n', 0))
        p = float(request.form.get('p', 0))
        k = float(request.form.get('k', 0))
        ph = float(request.form.get('ph', 6.5))
        temp = float(request.form.get('temperature', 25.0))
        humidity = float(request.form.get('humidity', 70.0))
        rainfall = float(request.form.get('rainfall', 100.0))
        soil_type = request.form.get('soil_type', 'Loamy')
        state = request.form.get('state', '')
        district = request.form.get('district', '')
        farm_size = request.form.get('farm_size', 1.0)
        
        # Run ML model prediction
        try:
            crop_label, confidence = predict.predict_crop(n, p, k, temp, humidity, ph, rainfall)
        except Exception as e:
            flash(f"Prediction error: {e}. Please ensure the model is trained.", 'danger')
            return redirect(url_for('recommend'))
            
        # Store recommendation
        farmer_id = session['farmer_id']
        try:
            rec_id = database.execute_query(
                """INSERT INTO recommendations (farmer_id, nitrogen, phosphorus, potassium, ph, temperature, humidity, rainfall, soil_type, predicted_crop, confidence_score)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                (farmer_id, n, p, k, ph, temp, humidity, rainfall, soil_type, crop_label, confidence)
            )
            return redirect(url_for('recommendation_results', rec_id=rec_id))
        except Exception as e:
            flash(f"Database error saving recommendation: {e}", 'danger')
            return redirect(url_for('recommend'))
            
    return render_template('crop_recommendation.html')

@app.route('/recommendation/<int:rec_id>')
@login_required
def recommendation_results(rec_id):
    farmer_id = session['farmer_id']
    try:
        # Load prediction record
        rec = database.execute_query(
            "SELECT * FROM recommendations WHERE id = %s AND farmer_id = %s",
            (rec_id, farmer_id), fetch='one'
        )
        if not rec:
            flash('Recommendation record not found.', 'danger')
            return redirect(url_for('farmer_dashboard'))
            
        # Look up crop details from database
        crop_info = database.execute_query(
            "SELECT * FROM crops WHERE LOWER(crop_name) = LOWER(%s)",
            (rec['predicted_crop'],), fetch='one'
        )
        
        # If crop is not in database, fallback default
        if not crop_info:
            crop_info = {
                'id': None,
                'crop_name': rec['predicted_crop'].capitalize(),
                'season': 'Kharif/Rabi',
                'soil_type': rec['soil_type'],
                'crop_duration': '100-120 Days',
                'crop_description': 'This crop has been recommended based on soil nutrients. Details can be managed by the administrator.',
                'crop_image': 'default_crop.jpg'
            }
            
        # Get seeds and fertilizers
        seeds = []
        fertilizers = []
        if crop_info['id']:
            seeds = database.execute_query(
                "SELECT * FROM seed_varieties WHERE crop_id = %s",
                (crop_info['id'],), fetch='all'
            )
            fertilizers = database.execute_query(
                "SELECT * FROM fertilizers WHERE crop_id = %s",
                (crop_info['id'],), fetch='all'
            )
            
        # NPK deficiency calculations
        deficiency_notes = []
        if rec['nitrogen'] < 40:
            deficiency_notes.append("Nitrogen (N) level is low. Add nitrogenous fertilizer like Urea to support leaf development and plant vigor.")
        if rec['phosphorus'] < 45:
            deficiency_notes.append("Phosphorus (P) level is low. Add phosphatic fertilizers like Single Super Phosphate (SSP) or DAP to boost root growth.")
        if rec['potassium'] < 40:
            deficiency_notes.append("Potassium (K) level is low. Add potash fertilizers like Muriate of Potash (MOP) to improve disease resistance and grain quality.")
            
        if not deficiency_notes:
            deficiency_notes.append("Nutrient levels (N, P, K) look healthy and balanced for the recommended crop!")
            
    except Exception as e:
        flash(f"Error loading results: {e}", 'danger')
        return redirect(url_for('farmer_dashboard'))
        
    return render_template('recommendation_results.html', rec=rec, crop=crop_info, seeds=seeds, fertilizers=fertilizers, deficiencies=deficiency_notes)

@app.route('/history')
@login_required
def history():
    farmer_id = session['farmer_id']
    query = request.args.get('query', '')
    crop_filter = request.args.get('crop', '')
    
    
    sql = "SELECT * FROM recommendations WHERE farmer_id = %s"
    params = [farmer_id]
    
    if query:
        sql += " AND soil_type LIKE %s"
        params.append(f"%{query}%")
    if crop_filter:
        sql += " AND LOWER(predicted_crop) = LOWER(%s)"
        params.append(crop_filter)
        
    sql += " ORDER BY recommendation_date DESC"
    
    try:
        records = database.execute_query(sql, tuple(params), fetch='all')
        # Get unique predicted crops for filter dropdown
        crop_list = database.execute_query(
            "SELECT DISTINCT predicted_crop FROM recommendations WHERE farmer_id = %s",
            (farmer_id,), fetch='all'
        )
    except Exception:
        records = []
        crop_list = []
        
    return render_template('history.html', records=records, crop_list=[c['predicted_crop'] for c in crop_list], query=query, crop_filter=crop_filter)

@app.route('/download_pdf/<int:rec_id>')
@login_required
def download_pdf(rec_id):
    farmer_id = session['farmer_id']
    
    try:
        # Load recommendation
        rec = database.execute_query(
            "SELECT * FROM recommendations WHERE id = %s AND farmer_id = %s",
            (rec_id, farmer_id), fetch='one'
        )
        if not rec:
            flash('Record not found', 'danger')
            return redirect(url_for('farmer_dashboard'))
            
        # Load farmer
        farmer = database.execute_query("SELECT * FROM farmers WHERE id = %s", (farmer_id,), fetch='one')
        
        # Load crop
        crop_info = database.execute_query(
            "SELECT * FROM crops WHERE LOWER(crop_name) = LOWER(%s)",
            (rec['predicted_crop'],), fetch='one'
        )
        if not crop_info:
            crop_info = {
                'id': None,
                'crop_name': rec['predicted_crop'].capitalize(),
                'season': 'Kharif/Rabi',
                'soil_type': rec['soil_type'],
                'crop_duration': '100-120 Days',
                'crop_description': 'This crop has been recommended based on soil nutrients.'
            }
            
        # Load seeds & fertilizers
        seeds = []
        fertilizers = []
        if crop_info.get('id'):
            seeds = database.execute_query("SELECT * FROM seed_varieties WHERE crop_id = %s", (crop_info['id'],), fetch='all')
            fertilizers = database.execute_query("SELECT * FROM fertilizers WHERE crop_id = %s", (crop_info['id'],), fetch='all')
            
        # Generate PDF using ReportLab helper
        from io import BytesIO
        from reportlab.lib.pagesizes import letter
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib import colors

        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
        story = []
        styles = getSampleStyleSheet()
        
        title_style = ParagraphStyle(
            'TitleStyle', parent=styles['Heading1'], fontName='Helvetica-Bold', fontSize=22,
            textColor=colors.HexColor('#1b4332'), spaceAfter=8, alignment=1
        )
        sub_style = ParagraphStyle(
            'SubTitleStyle', parent=styles['Normal'], fontSize=10, textColor=colors.HexColor('#555555'),
            spaceAfter=20, alignment=1
        )
        h2_style = ParagraphStyle(
            'H2Style', parent=styles['Heading2'], fontName='Helvetica-Bold', fontSize=13,
            textColor=colors.HexColor('#40916c'), spaceBefore=10, spaceAfter=6
        )
        body_style = ParagraphStyle(
            'BodyStyle', parent=styles['BodyText'], fontSize=9, leading=12
        )
        
        # Header
        story.append(Paragraph("KRISHIMITRA REPORT", title_style))
        story.append(Paragraph("AI-Powered Crop, Seed, & Fertilizer Recommendation System", sub_style))
        story.append(Spacer(1, 10))
        
        # Farmer details
        story.append(Paragraph("Farmer & Farm Information", h2_style))
        farmer_data = [
            [Paragraph("<b>Farmer Name:</b>", body_style), Paragraph(farmer['full_name'], body_style),
             Paragraph("<b>Mobile Number:</b>", body_style), Paragraph(farmer['mobile'], body_style)],
            [Paragraph("<b>Location:</b>", body_style), Paragraph(f"{farmer['village']}, {farmer['district']}, {farmer['state']}", body_style),
             Paragraph("<b>Date & Time:</b>", body_style), Paragraph(str(rec['recommendation_date']), body_style)]
        ]
        t_farmer = Table(farmer_data, colWidths=[100, 160, 90, 150])
        t_farmer.setStyle(TableStyle([
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
            ('LINEBELOW', (0,-1), (-1,-1), 0.5, colors.lightgrey),
        ]))
        story.append(t_farmer)
        story.append(Spacer(1, 10))
        
        # Soil input parameters
        story.append(Paragraph("Soil Analysis Parameters", h2_style))
        soil_data = [
            [Paragraph("<b>Nitrogen (N)</b>", body_style), Paragraph(f"{rec['nitrogen']} ppm", body_style),
             Paragraph("<b>Phosphorus (P)</b>", body_style), Paragraph(f"{rec['phosphorus']} ppm", body_style),
             Paragraph("<b>Potassium (K)</b>", body_style), Paragraph(f"{rec['potassium']} ppm", body_style)],
            [Paragraph("<b>Soil pH</b>", body_style), Paragraph(str(rec['ph']), body_style),
             Paragraph("<b>Temperature</b>", body_style), Paragraph(f"{rec['temperature']} °C", body_style),
             Paragraph("<b>Humidity</b>", body_style), Paragraph(f"{rec['humidity']} %", body_style)],
            [Paragraph("<b>Rainfall</b>", body_style), Paragraph(f"{rec['rainfall']} mm", body_style),
             Paragraph("<b>Soil Type</b>", body_style), Paragraph(rec['soil_type'], body_style),
             Paragraph("", body_style), Paragraph("", body_style)]
        ]
        t_soil = Table(soil_data, colWidths=[90, 80, 95, 80, 85, 80])
        t_soil.setStyle(TableStyle([
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('GRID', (0,0), (-1,-1), 0.5, colors.lightgrey),
            ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f8f9fa')),
            ('TOPPADDING', (0,0), (-1,-1), 5),
            ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ]))
        story.append(t_soil)
        story.append(Spacer(1, 10))
        
        # Recommendations
        story.append(Paragraph("AI Recommendations Results", h2_style))
        rec_data = [
            [Paragraph("<b>Recommended Crop:</b>", body_style), Paragraph(f"<b>{rec['predicted_crop'].capitalize()}</b> (Confidence: {rec['confidence_score']*100:.1f}%)", body_style)],
            [Paragraph("<b>Season:</b>", body_style), Paragraph(crop_info.get('season', 'N/A'), body_style)],
            [Paragraph("<b>Crop Duration:</b>", body_style), Paragraph(crop_info.get('crop_duration', 'N/A'), body_style)],
            [Paragraph("<b>Crop Description:</b>", body_style), Paragraph(crop_info.get('crop_description', 'N/A'), body_style)]
        ]
        t_rec = Table(rec_data, colWidths=[120, 380])
        t_rec.setStyle(TableStyle([
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('GRID', (0,0), (-1,-1), 0.5, colors.lightgrey),
            ('BACKGROUND', (0,0), (0,-1), colors.HexColor('#e8f5e9')),
            ('TOPPADDING', (0,0), (-1,-1), 5),
            ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ]))
        story.append(t_rec)
        story.append(Spacer(1, 10))
        
        # Seeds table
        if seeds:
            story.append(Paragraph("Seed Recommendations", h2_style))
            seed_rows = [[Paragraph("<b>Variety Name</b>", body_style), Paragraph("<b>Sowing Period</b>", body_style), Paragraph("<b>Expected Yield</b>", body_style), Paragraph("<b>Quantity Required</b>", body_style)]]
            for s in seeds:
                seed_rows.append([
                    Paragraph(s['variety_name'], body_style),
                    Paragraph(s['sowing_period'], body_style),
                    Paragraph(s['expected_yield'], body_style),
                    Paragraph(s['seed_quantity'], body_style)
                ])
            t_seed = Table(seed_rows, colWidths=[140, 110, 125, 125])
            t_seed.setStyle(TableStyle([
                ('VALIGN', (0,0), (-1,-1), 'TOP'),
                ('GRID', (0,0), (-1,-1), 0.5, colors.lightgrey),
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#e8f5e9')),
                ('TOPPADDING', (0,0), (-1,-1), 5),
                ('BOTTOMPADDING', (0,0), (-1,-1), 5),
            ]))
            story.append(t_seed)
            story.append(Spacer(1, 10))
            
        # Fertilizers table
        if fertilizers:
            story.append(Paragraph("Fertilizer Application Details", h2_style))
            fert_rows = [[Paragraph("<b>Fertilizer</b>", body_style), Paragraph("<b>Recommended Quantity</b>", body_style), Paragraph("<b>Application Schedule</b>", body_style)]]
            for f in fertilizers:
                fert_rows.append([
                    Paragraph(f['fertilizer_name'], body_style),
                    Paragraph(f['quantity'], body_style),
                    Paragraph(f['application_time'], body_style)
                ])
            t_fert = Table(fert_rows, colWidths=[150, 150, 200])
            t_fert.setStyle(TableStyle([
                ('VALIGN', (0,0), (-1,-1), 'TOP'),
                ('GRID', (0,0), (-1,-1), 0.5, colors.lightgrey),
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#e8f5e9')),
                ('TOPPADDING', (0,0), (-1,-1), 5),
                ('BOTTOMPADDING', (0,0), (-1,-1), 5),
            ]))
            story.append(t_fert)
            story.append(Spacer(1, 15))
            
        story.append(Paragraph("<font color='grey'>* This report is generated by KrishiMitra AI Decision Support System.</font>", body_style))
        
        doc.build(story)
        buffer.seek(0)
        
        return send_file(buffer, as_attachment=True, download_name=f"KrishiMitra_Report_{rec_id}.pdf", mimetype='application/pdf')
        
    except Exception as e:
        flash(f"PDF generation error: {e}", 'danger')
        return redirect(url_for('farmer_dashboard'))


# ======================================================
# ADMIN PORTAL MODULES
# ======================================================
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        try:
            print("Username entered:", username)

            all_admins = database.execute_query(
            "SELECT * FROM admin",
            fetch='all'
            )

            print("ALL ADMINS:", all_admins)

            admin = database.execute_query(
            "SELECT * FROM admin WHERE username = %s",
            (username,),
            fetch='one'
             )

            print("Admin record:", admin)

            if admin:
                print("Stored hash:", admin['password'])
                print("Entered password:", password)
                print("Password match:", check_password_hash(admin['password'], password))
            if admin and check_password_hash(admin['password'], password):
                session['admin_id'] = admin['id']
                session['admin_user'] = admin['username']
                flash('Welcome to Admin Portal.', 'success')
                return redirect(url_for('admin_dashboard'))
            else:
                flash('Invalid admin credentials.', 'danger')
        except Exception as e:
            flash(f"Database error: {e}", 'danger')
            
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    try:
        farmers_cnt = database.execute_query("SELECT COUNT(*) as cnt FROM farmers", fetch='one')['cnt']
        recs_cnt = database.execute_query("SELECT COUNT(*) as cnt FROM recommendations", fetch='one')['cnt']
        crops_cnt = database.execute_query("SELECT COUNT(*) as cnt FROM crops", fetch='one')['cnt']
        seeds_cnt = database.execute_query("SELECT COUNT(*) as cnt FROM seed_varieties", fetch='one')['cnt']
        
        # Get charts data: Top predicted crops
        top_crops = database.execute_query(
            "SELECT predicted_crop as name, COUNT(*) as value FROM recommendations GROUP BY predicted_crop ORDER BY value DESC LIMIT 5",
            fetch='all'
        )
    except Exception:
        farmers_cnt = recs_cnt = crops_cnt = seeds_cnt = 0
        top_crops = []
        
    return render_template(
        'admin_dashboard.html',
        farmers_cnt=farmers_cnt,
        recs_cnt=recs_cnt,
        crops_cnt=crops_cnt,
        seeds_cnt=seeds_cnt,
        top_crops=top_crops
    )

@app.route('/admin/farmers', methods=['GET', 'POST'])
@admin_required
def admin_farmers():
    query = request.args.get('query', '')
    try:
        sql = "SELECT id, full_name, mobile, email, village, district, state, created_at FROM farmers"
        params = []
        if query:
            sql += " WHERE full_name LIKE %s OR email LIKE %s OR mobile LIKE %s"
            params = [f"%{query}%", f"%{query}%", f"%{query}%"]
        sql += " ORDER BY created_at DESC"
        farmers = database.execute_query(sql, tuple(params), fetch='all')
    except Exception as e:
        farmers = []
        flash(f"Error loading farmers: {e}", 'danger')
        
    return render_template('admin_farmers.html', farmers=farmers, query=query)

@app.route('/admin/farmers/delete/<int:farmer_id>', methods=['POST'])
@admin_required
def delete_farmer(farmer_id):
    try:
        database.execute_query("DELETE FROM farmers WHERE id = %s", (farmer_id,))
        flash('Farmer record deleted successfully.', 'success')
    except Exception as e:
        flash(f"Delete failed: {e}", 'danger')
    return redirect(url_for('admin_farmers'))

# CROPS CRUD
@app.route('/admin/crops', methods=['GET', 'POST'])
@admin_required
def admin_crops():
    if request.method == 'POST':
        # Add new crop
        crop_name = request.form.get('crop_name')
        season = request.form.get('season')
        soil_type = request.form.get('soil_type')
        crop_duration = request.form.get('crop_duration')
        crop_description = request.form.get('crop_description')
        crop_image = request.form.get('crop_image') or 'default_crop.jpg'
        
        try:
            database.execute_query(
                """INSERT INTO crops (crop_name, season, soil_type, crop_duration, crop_description, crop_image)
                   VALUES (%s, %s, %s, %s, %s, %s)""",
                (crop_name, season, soil_type, crop_duration, crop_description, crop_image)
            )
            flash('New crop added successfully!', 'success')
        except Exception as e:
            flash(f"Failed to add crop: {e}", 'danger')
        return redirect(url_for('admin_crops'))
        
    try:
        crops = database.execute_query("SELECT * FROM crops ORDER BY crop_name ASC", fetch='all')
    except Exception:
        crops = []
    return render_template('admin_crops.html', crops=crops)

@app.route('/admin/crops/edit/<int:crop_id>', methods=['POST'])
@admin_required
def edit_crop(crop_id):
    crop_name = request.form.get('crop_name')
    season = request.form.get('season')
    soil_type = request.form.get('soil_type')
    crop_duration = request.form.get('crop_duration')
    crop_description = request.form.get('crop_description')
    crop_image = request.form.get('crop_image')
    
    try:
        database.execute_query(
            """UPDATE crops SET crop_name = %s, season = %s, soil_type = %s, crop_duration = %s, crop_description = %s, crop_image = %s
               WHERE id = %s""",
            (crop_name, season, soil_type, crop_duration, crop_description, crop_image, crop_id)
        )
        flash('Crop updated successfully.', 'success')
    except Exception as e:
        flash(f"Edit failed: {e}", 'danger')
    return redirect(url_for('admin_crops'))

@app.route('/admin/crops/delete/<int:crop_id>', methods=['POST'])
@admin_required
def delete_crop(crop_id):
    try:
        database.execute_query("DELETE FROM crops WHERE id = %s", (crop_id,))
        flash('Crop deleted successfully.', 'success')
    except Exception as e:
        flash(f"Delete failed: {e}", 'danger')
    return redirect(url_for('admin_crops'))

# SEEDS CRUD
@app.route('/admin/seeds', methods=['GET', 'POST'])
@admin_required
def admin_seeds():
    if request.method == 'POST':
        crop_id = int(request.form.get('crop_id'))
        variety_name = request.form.get('variety_name')
        sowing_period = request.form.get('sowing_period')
        expected_yield = request.form.get('expected_yield')
        seed_quantity = request.form.get('seed_quantity')
        
        try:
            database.execute_query(
                """INSERT INTO seed_varieties (crop_id, variety_name, sowing_period, expected_yield, seed_quantity)
                   VALUES (%s, %s, %s, %s, %s)""",
                (crop_id, variety_name, sowing_period, expected_yield, seed_quantity)
            )
            flash('Seed variety added successfully.', 'success')
        except Exception as e:
            flash(f"Failed to add seed: {e}", 'danger')
        return redirect(url_for('admin_seeds'))
        
    try:
        seeds = database.execute_query(
            """SELECT sv.*, c.crop_name FROM seed_varieties sv 
               JOIN crops c ON sv.crop_id = c.id ORDER BY c.crop_name ASC""",
            fetch='all'
        )
        crops = database.execute_query("SELECT id, crop_name FROM crops ORDER BY crop_name ASC", fetch='all')
    except Exception:
        seeds = []
        crops = []
    return render_template('admin_seeds.html', seeds=seeds, crops=crops)

@app.route('/admin/seeds/edit/<int:seed_id>', methods=['POST'])
@admin_required
def edit_seed(seed_id):
    crop_id = int(request.form.get('crop_id'))
    variety_name = request.form.get('variety_name')
    sowing_period = request.form.get('sowing_period')
    expected_yield = request.form.get('expected_yield')
    seed_quantity = request.form.get('seed_quantity')
    
    try:
        database.execute_query(
            """UPDATE seed_varieties SET crop_id = %s, variety_name = %s, sowing_period = %s, expected_yield = %s, seed_quantity = %s
               WHERE id = %s""",
            (crop_id, variety_name, sowing_period, expected_yield, seed_quantity, seed_id)
        )
        flash('Seed variety updated successfully.', 'success')
    except Exception as e:
        flash(f"Edit failed: {e}", 'danger')
    return redirect(url_for('admin_seeds'))

@app.route('/admin/seeds/delete/<int:seed_id>', methods=['POST'])
@admin_required
def delete_seed(seed_id):
    try:
        database.execute_query("DELETE FROM seed_varieties WHERE id = %s", (seed_id,))
        flash('Seed variety deleted.', 'success')
    except Exception as e:
        flash(f"Delete failed: {e}", 'danger')
    return redirect(url_for('admin_seeds'))

# FERTILIZERS CRUD
@app.route('/admin/fertilizers', methods=['GET', 'POST'])
@admin_required
def admin_fertilizers():
    if request.method == 'POST':
        crop_id = int(request.form.get('crop_id'))
        fertilizer_name = request.form.get('fertilizer_name')
        quantity = request.form.get('quantity')
        application_time = request.form.get('application_time')
        
        try:
            database.execute_query(
                """INSERT INTO fertilizers (crop_id, fertilizer_name, quantity, application_time)
                   VALUES (%s, %s, %s, %s)""",
                (crop_id, fertilizer_name, quantity, application_time)
            )
            flash('Fertilizer schedule added successfully.', 'success')
        except Exception as e:
            flash(f"Failed to add fertilizer: {e}", 'danger')
        return redirect(url_for('admin_fertilizers'))
        
    try:
        fertilizers = database.execute_query(
            """SELECT f.*, c.crop_name FROM fertilizers f
               JOIN crops c ON f.crop_id = c.id ORDER BY c.crop_name ASC""",
            fetch='all'
        )
        crops = database.execute_query("SELECT id, crop_name FROM crops ORDER BY crop_name ASC", fetch='all')
    except Exception:
        fertilizers = []
        crops = []
    return render_template('admin_fertilizers.html', fertilizers=fertilizers, crops=crops)

@app.route('/admin/fertilizers/edit/<int:fert_id>', methods=['POST'])
@admin_required
def edit_fertilizer(fert_id):
    crop_id = int(request.form.get('crop_id'))
    fertilizer_name = request.form.get('fertilizer_name')
    quantity = request.form.get('quantity')
    application_time = request.form.get('application_time')
    
    try:
        database.execute_query(
            """UPDATE fertilizers SET crop_id = %s, fertilizer_name = %s, quantity = %s, application_time = %s
               WHERE id = %s""",
            (crop_id, fertilizer_name, quantity, application_time, fert_id)
        )
        flash('Fertilizer schedule updated successfully.', 'success')
    except Exception as e:
        flash(f"Edit failed: {e}", 'danger')
    return redirect(url_for('admin_fertilizers'))

@app.route('/admin/fertilizers/delete/<int:fert_id>', methods=['POST'])
@admin_required
def delete_fertilizer(fert_id):
    try:
        database.execute_query("DELETE FROM fertilizers WHERE id = %s", (fert_id,))
        flash('Fertilizer schedule deleted.', 'success')
    except Exception as e:
        flash(f"Delete failed: {e}", 'danger')
    return redirect(url_for('admin_fertilizers'))

# VIEW REPORTS
@app.route('/admin/reports')
@admin_required
def admin_reports():
    query = request.args.get('query', '')
    try:
        # Load reports, join with farmers
        sql = """SELECT r.*, f.full_name, f.mobile, f.email FROM recommendations r
                 JOIN farmers f ON r.farmer_id = f.id"""
        params = []
        if query:
            sql += " WHERE f.full_name LIKE %s OR r.predicted_crop LIKE %s"
            params = [f"%{query}%", f"%{query}%"]
        sql += " ORDER BY r.recommendation_date DESC"
        
        reports = database.execute_query(sql, tuple(params), fetch='all')
        
        # Load activity log stats (number of recommendations per farmer)
        activity = database.execute_query(
            """SELECT f.full_name, f.email, COUNT(r.id) as total_recs, MAX(r.recommendation_date) as last_activity
               FROM farmers f
               LEFT JOIN recommendations r ON f.id = r.farmer_id
               GROUP BY f.id
               ORDER BY total_recs DESC""",
            fetch='all'
        )
    except Exception as e:
        reports = []
        activity = []
        flash(f"Error loading reports: {e}", 'danger')
        
    return render_template('admin_reports.html', reports=reports, activity=activity, query=query)

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_id', None)
    session.pop('admin_user', None)
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)
