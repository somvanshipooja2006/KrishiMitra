import os
import mysql.connector
from mysql.connector import Error

# Configuration from environment variables, fallback to standard defaults
DB_HOST = os.environ.get('DB_HOST', 'localhost')
DB_USER = os.environ.get('DB_USER', 'root')
# DB_PASSWORD = os.environ.get('newpassword', '')  # Default empty password in XAMPP/WAMP
DB_PASSWORD = "newpassword"
DB_NAME = os.environ.get('DB_NAME', 'krishimitra_db')

def get_connection(include_db=True):
    """
    Creates and returns a MySQL database connection.
    """
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password="newpassword",
            database=DB_NAME if include_db else None,
            # charset='utf8mb4',
            # collation='utf8mb4_unicode_ci'
        )
        return conn
    except Error as e:
        print(f"MySQL Connection Error: {e}")
        return None

def execute_query(query, params=None, fetch=None):
    """
    Executes a query and returns results.
    fetch can be 'all', 'one', or None.
    """
    conn = get_connection()
    if not conn:
        return None
    
    cursor = conn.cursor(dictionary=True)
    result = None
    try:
        cursor.execute(query, params or ())
        if fetch == 'all':
            result = cursor.fetchall()
        elif fetch == 'one':
            result = cursor.fetchone()
        else:
            conn.commit()
            result = cursor.lastrowid if cursor.lastrowid else cursor.rowcount
    except Error as e:
        print(f"Database Query Error: {e}")
        conn.rollback()
        raise e
    finally:
        cursor.close()
        conn.close()
    return result

def setup_database():
    """
    Creates the database and runs schema.sql and seed_data.sql scripts.
    """
    print("Initializing Database Setup...")
    # Step 1: Connect to server without database to create it if it doesn't exist
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password="newpassword"
        )
        cursor = conn.cursor()
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME};")
        cursor.close()
        conn.close()
        print(f"Database '{DB_NAME}' checked/created.")
    except Error as e:
        print(f"Failed to connect to MySQL server: {e}")
        print("Please make sure MySQL is installed and running on your local machine.")
        return False

    # Step 2: Connect to database and execute scripts
    conn = get_connection(include_db=True)
    if not conn:
        print("Could not connect to the database after creation.")
        return False
    
    try:
        cursor = conn.cursor()
        
        def split_sql_statements(sql_text):
            statements = []
            current_statement = []
            in_single_quote = False
            in_double_quote = False
            in_backtick = False
            escape = False
            
            for char in sql_text:
                if escape:
                    current_statement.append(char)
                    escape = False
                    continue
                    
                if char == '\\':
                    current_statement.append(char)
                    escape = True
                    continue
                    
                if char == "'" and not in_double_quote and not in_backtick:
                    in_single_quote = not in_single_quote
                elif char == '"' and not in_single_quote and not in_backtick:
                    in_double_quote = not in_double_quote
                elif char == '`' and not in_single_quote and not in_double_quote:
                    in_backtick = not in_backtick
                    
                if char == ';' and not in_single_quote and not in_double_quote and not in_backtick:
                    statement_str = "".join(current_statement).strip()
                    if statement_str:
                        statements.append(statement_str)
                    current_statement = []
                else:
                    current_statement.append(char)
                    
            statement_str = "".join(current_statement).strip()
            if statement_str:
                statements.append(statement_str)
                
            return statements

        def execute_sql_file(file_path):
            if not os.path.exists(file_path):
                print(f"SQL file not found: {file_path}")
                return False
            
            print(f"Executing SQL file: {file_path}")
            with open(file_path, 'r', encoding='utf-8') as f:
                sql_content = f.read()
            
            statements = split_sql_statements(sql_content)
            for statement in statements:
                cursor.execute(statement)

            conn.commit()
            print(f"Completed execution of {file_path}")
            return True

        # Run schema
        execute_sql_file('schema.sql')
        # Run seeding
        execute_sql_file('seed_data.sql')
        
        cursor.close()
        conn.close()
        print("Database setup and seeding completed successfully!")
        return True
    except Error as e:
        print(f"Error executing database scripts: {e}")
        if conn:
            conn.rollback()
            conn.close()
        return False

if __name__ == '__main__':
    setup_database()
