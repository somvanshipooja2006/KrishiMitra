import os
import pickle
import numpy as np
import pandas as pd

class CropPredictor:
    def __init__(self, model_path=None):
        if model_path is None:
            model_path = os.path.join(os.path.dirname(__file__), 'models', 'model.pkl')
        self.model_path = model_path
        self._model = None

    def _load_model(self):
        if self._model is None:
            if not os.path.exists(self.model_path):
                raise FileNotFoundError(f"Model file not found at {self.model_path}. Please train the model first.")
            with open(self.model_path, 'rb') as f:
                self._model = pickle.load(f)

    def predict(self, n, p, k, temp, humidity, ph, rainfall):
        """
        Predicts crop and returns (crop_label, confidence_score)
        """
        self._load_model()
        # Shape of features must be (1, 7), matches column headers from dataset
        features = pd.DataFrame(
            [[float(n), float(p), float(k), float(temp), float(humidity), float(ph), float(rainfall)]],
            columns=['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']
        )
        
        # Predict label
        prediction = self._model.predict(features)[0]
        
        # Get confidence score
        probabilities = self._model.predict_proba(features)[0]
        classes = self._model.classes_
        class_idx = np.where(classes == prediction)[0][0]
        confidence = float(probabilities[class_idx])
        
        return str(prediction), confidence

# Singleton instances or helper function
_predictor = None

def predict_crop(n, p, k, temp, humidity, ph, rainfall):
    global _predictor
    if _predictor is None:
        _predictor = CropPredictor()
    return _predictor.predict(n, p, k, temp, humidity, ph, rainfall)
