import os
import pickle
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

def train_model():
    # Ensure directories exist
    os.makedirs('models', exist_ok=True)
    
    dataset_path = os.path.join('dataset', 'crop_recommendation.csv')
    if not os.path.exists(dataset_path):
        raise FileNotFoundError(f"Dataset not found at {dataset_path}")
        
    print("Loading dataset...")
    df = pd.read_csv(dataset_path)
    
    # Verify columns
    expected_cols = {'N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall', 'label'}
    actual_cols = set(df.columns)
    if not expected_cols.issubset(actual_cols):
        raise ValueError(f"Dataset is missing required columns. Expected: {expected_cols}, Found: {df.columns.tolist()}")
        
    print("Pre-processing data...")
    # Features and Target
    X = df[['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']]
    y = df['label']
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    print(f"Training set size: {X_train.shape[0]} samples")
    print(f"Testing set size: {X_test.shape[0]} samples")
    
    # Initialize and train Decision Tree Classifier
    print("Training Decision Tree Classifier...")
    model = DecisionTreeClassifier(random_state=42, min_samples_leaf=2)
    model.fit(X_train, y_train)
    
    # Evaluate model
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Model Training Completed. Test Accuracy: {accuracy * 100:.2f}%")
    
    # Save the model
    model_path = os.path.join('models', 'model.pkl')
    with open(model_path, 'wb') as f:
        pickle.dump(model, f)
    print(f"Model saved successfully to {model_path}")

if __name__ == '__main__':
    train_model()
