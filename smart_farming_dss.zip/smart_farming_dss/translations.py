TRANSLATIONS = {
    'en': {
        # General & Navigation
        'app_title': 'KrishiMitra',
        'home': 'Home',
        'dashboard': 'Dashboard',
        'crop_recommendation': 'Crop Recommendation',
        'seed_recommendation': 'Seed Recommendation',
        'fertilizer_recommendation': 'Fertilizer Recommendation',
        'history': 'History',
        'profile': 'Profile',
        'logout': 'Logout',
        'login': 'Login',
        'register': 'Register',
        'admin_panel': 'Admin Panel',
        'language': 'Language',
        
        # Landing Page
        'hero_title': 'KrishiMitra: AI-Powered Smart Farming Support',
        'hero_subtitle': 'Empowering farmers with intelligent crop, seed, and fertilizer recommendations based on real-time soil data and weather patterns.',
        'get_started': 'Get Started',
        'features': 'Key Features',
        'about': 'About Us',
        'contact': 'Contact Support',
        
        # Authentication
        'farmer_login': 'Farmer Login',
        'farmer_register': 'Farmer Registration',
        'admin_login': 'Admin Login',
        'email': 'Email Address',
        'password': 'Password',
        'confirm_password': 'Confirm Password',
        'full_name': 'Full Name',
        'mobile': 'Mobile Number',
        'village': 'Village Name',
        'district': 'District',
        'state': 'State',
        'reset_password': 'Reset Password',
        'submit': 'Submit',
        'dont_have_account': "Don't have an account?",
        'already_have_account': 'Already have an account?',
        'new_password': 'New Password',
        
        # Farmer Dashboard
        'welcome': 'Welcome',
        'weather_info': 'Current Weather Info',
        'soil_health': 'Soil Health & Inputs',
        'recent_predictions': 'Recent Recommendations',
        'view_all': 'View All',
        'download_pdf': 'Download PDF Report',
        
        # Recommendations Form
        'nitrogen': 'Nitrogen (N) - ppm',
        'phosphorus': 'Phosphorus (P) - ppm',
        'potassium': 'Potassium (K) - ppm',
        'ph': 'Soil pH (0-14)',
        'temperature': 'Temperature (°C)',
        'humidity': 'Humidity (%)',
        'rainfall': 'Rainfall (mm)',
        'soil_type': 'Soil Type',
        'farm_size': 'Farm Size (Acres)',
        'get_recommendation': 'Get Recommendation',
        
        # Soil Types
        'clayey': 'Clayey',
        'loamy': 'Loamy',
        'sandy': 'Sandy',
        'black': 'Black Soil',
        'red': 'Red Soil',
        'alluvial': 'Alluvial Soil',
        
        # Recommendation Output
        'recommendation_result': 'Recommendation Result',
        'recommended_crop': 'Recommended Crop',
        'confidence_score': 'Confidence Score',
        'suitable_season': 'Suitable Season',
        'crop_duration': 'Crop Duration',
        'crop_desc': 'Description',
        
        # Seeds
        'seed_details': 'Recommended Seed Varieties',
        'variety_name': 'Variety Name',
        'sowing_period': 'Sowing Period',
        'expected_yield': 'Expected Yield',
        'seed_qty': 'Seed Quantity Required',
        
        # Fertilizers
        'fertilizer_details': 'Recommended Fertilizer Schedule',
        'nutrient_deficiency': 'Nutrient Deficiency Check',
        'recommended_fert': 'Recommended Fertilizer',
        'fert_qty': 'Application Quantity',
        'fert_schedule': 'Application Schedule',
        
        # Weather
        'weather_card': 'Weather Card',
        'wind_speed': 'Wind Speed',
        'forecast': 'Rainfall Forecast',
        'condition': 'Weather Condition',
        'temp_current': 'Current Temp',
        'humidity_current': 'Current Humidity',
        
        # Messages
        'login_success': 'Successfully logged in!',
        'login_fail': 'Invalid email/mobile or password.',
        'reg_success': 'Registration successful! Please login.',
        'profile_update_success': 'Profile updated successfully!',
        'reset_success': 'Password reset successful!',
        'access_denied': 'Access denied. Please login first.'
    },
    
    'hi': {
        # General & Navigation
        'app_title': 'कृषिमित्र',
        'home': 'मुख्य पृष्ठ',
        'dashboard': 'डैशबोर्ड',
        'crop_recommendation': 'फसल अनुशंसा',
        'seed_recommendation': 'बीज अनुशंसा',
        'fertilizer_recommendation': 'उर्वरक अनुशंसा',
        'history': 'इतिहास',
        'profile': 'प्रोफ़ाइल',
        'logout': 'लॉगआउट',
        'login': 'लॉगिन',
        'register': 'पंजीकरण',
        'admin_panel': 'एडमिन पैनल',
        'language': 'भाषा',
        
        # Landing Page
        'hero_title': 'कृषिमित्र: एआई-संचालित स्मार्ट कृषि सहायता',
        'hero_subtitle': 'वास्तविक समय की मिट्टी की जानकारी और मौसम के आधार पर किसानों को फसल, बीज और उर्वरक की बुद्धिमान अनुशंसाएं प्रदान करना।',
        'get_started': 'शुरू करें',
        'features': 'मुख्य विशेषताएं',
        'about': 'हमारे बारे में',
        'contact': 'सहायता से संपर्क करें',
        
        # Authentication
        'farmer_login': 'किसान लॉगिन',
        'farmer_register': 'किसान पंजीकरण',
        'admin_login': 'एडमिन लॉगिन',
        'email': 'ईमेल पता',
        'password': 'पासवर्ड',
        'confirm_password': 'पासवर्ड की पुष्टि करें',
        'full_name': 'पूरा नाम',
        'mobile': 'मोबाइल नंबर',
        'village': 'गांव का नाम',
        'district': 'जिला',
        'state': 'राज्य',
        'reset_password': 'पासवर्ड रीसेट करें',
        'submit': 'जमा करें',
        'dont_have_account': 'खाता नहीं है?',
        'already_have_account': 'पहले से ही एक खाता है?',
        'new_password': 'नया पासवर्ड',
        
        # Farmer Dashboard
        'welcome': 'स्वागत हे',
        'weather_info': 'वर्तमान मौसम की जानकारी',
        'soil_health': 'मिट्टी का स्वास्थ्य और इनपुट',
        'recent_predictions': 'हालिया अनुशंसाएं',
        'view_all': 'सभी देखें',
        'download_pdf': 'पीडीएफ रिपोर्ट डाउनलोड करें',
        
        # Recommendations Form
        'nitrogen': 'नाइट्रोजन (N) - पीपीएम',
        'phosphorus': 'फास्फोरस (P) - पीपीएम',
        'potassium': 'पोटेशियम (K) - पीपीएम',
        'ph': 'मिट्टी का पीएच (0-14)',
        'temperature': 'तापमान (°C)',
        'humidity': 'नमी (%)',
        'rainfall': 'वर्षा (मिमी)',
        'soil_type': 'मिट्टी का प्रकार',
        'farm_size': 'खेत का आकार (एकड़)',
        'get_recommendation': 'अनुशंसा प्राप्त करें',
        
        # Soil Types
        'clayey': 'चिकनी मिट्टी (Clayey)',
        'loamy': 'दोमट मिट्टी (Loamy)',
        'sandy': 'रेतीली मिट्टी (Sandy)',
        'black': 'काली मिट्टी (Black Soil)',
        'red': 'लाल मिट्टी (Red Soil)',
        'alluvial': 'जलोढ़ मिट्टी (Alluvial)',
        
        # Recommendation Output
        'recommendation_result': 'अनुशंसा परिणाम',
        'recommended_crop': 'अनुशंसित फसल',
        'confidence_score': 'आत्मविश्वास स्कोर',
        'suitable_season': 'उपयुक्त मौसम',
        'crop_duration': 'फसल की अवधि',
        'crop_desc': 'विवरण',
        
        # Seeds
        'seed_details': 'अनुशंसित बीज किस्में',
        'variety_name': 'किस्म का नाम',
        'sowing_period': 'बुवाई की अवधि',
        'expected_yield': 'अपेक्षित उपज',
        'seed_qty': 'आवश्यक बीज मात्रा',
        
        # Fertilizers
        'fertilizer_details': 'अनुशंसित उर्वरक अनुसूची',
        'nutrient_deficiency': 'पोषक तत्वों की कमी की जांच',
        'recommended_fert': 'अनुशंसित उर्वरक',
        'fert_qty': 'प्रयोग मात्रा',
        'fert_schedule': 'प्रयोग अनुसूची',
        
        # Weather
        'weather_card': 'मौसम कार्ड',
        'wind_speed': 'हवा की गति',
        'forecast': 'वर्षा का अनुमान',
        'condition': 'मौसम की स्थिति',
        'temp_current': 'वर्तमान तापमान',
        'humidity_current': 'वर्तमान आर्द्रता',
        
        # Messages
        'login_success': 'सफलतापूर्वक लॉगिन किया गया!',
        'login_fail': 'अमान्य ईमेल/मोबाइल या पासवर्ड।',
        'reg_success': 'पंजीकरण सफल! कृपया लॉगिन करें।',
        'profile_update_success': 'प्रोफ़ाइल सफलतापूर्वक अपडेट की गई!',
        'reset_success': 'पासवर्ड रीसेट सफल!',
        'access_denied': 'प्रवेश निषेध। कृपया पहले लॉगिन करें।'
    },
    
    'mr': {
        # General & Navigation
        'app_title': 'कृषिमित्र',
        'home': 'मुख्य पृष्ठ',
        'dashboard': 'डॅशबोर्ड',
        'crop_recommendation': 'पीक शिफारस',
        'seed_recommendation': 'बियाणे शिफारस',
        'fertilizer_recommendation': 'खत शिफारस',
        'history': 'इतिहास',
        'profile': 'प्रोफाईल',
        'logout': 'लॉगआउट',
        'login': 'लॉगिन',
        'register': 'नोंदणी',
        'admin_panel': 'अॅडमिन पॅनेल',
        'language': 'भाषा',
        
        # Landing Page
        'hero_title': 'कृषिमित्र: एआय-आधारित स्मार्ट शेती सहाय्यक',
        'hero_subtitle': 'मातीचे घटक आणि हवामानाच्या आधारे शेतकऱ्यांना पीक, बियाणे आणि खतांच्या योग्य शिफारसी देणे.',
        'get_started': 'सुरू करा',
        'features': 'मुख्य वैशिष्ट्ये',
        'about': 'आमच्याबद्दल',
        'contact': 'संपर्क साधा',
        
        # Authentication
        'farmer_login': 'शेतकरी लॉगिन',
        'farmer_register': 'शेतकरी नोंदणी',
        'admin_login': 'अॅडमिन लॉगिन',
        'email': 'ईमेल पत्ता',
        'password': 'पासवर्ड',
        'confirm_password': 'पासवर्डची पुष्टी करा',
        'full_name': 'पूर्ण नाव',
        'mobile': 'मोबाईल नंबर',
        'village': 'गावाचे नाव',
        'district': 'जिल्हा',
        'state': 'राज्य',
        'reset_password': 'पासवर्ड रीसेट करा',
        'submit': 'जमा करा',
        'dont_have_account': 'खाते नाही का?',
        'already_have_account': 'आधीच खाते आहे का?',
        'new_password': 'नवीन पासवर्ड',
        
        # Farmer Dashboard
        'welcome': 'स्वागत आहे',
        'weather_info': 'सध्याच्या हवामानाची माहिती',
        'soil_health': 'मातीचे आरोग्य आणि घटक',
        'recent_predictions': 'अलीकडील शिफारसी',
        'view_all': 'सर्व पहा',
        'download_pdf': 'पीडीएफ अहवाल डाउनलोड करा',
        
        # Recommendations Form
        'nitrogen': 'नायट्रोजन (N) - ppm',
        'phosphorus': 'फॉस्फोरस (P) - ppm',
        'potassium': 'पोटॅशियम (K) - ppm',
        'ph': 'मातीचा पीएच (0-14)',
        'temperature': 'तापमान (°C)',
        'humidity': 'आर्द्रता (%)',
        'rainfall': 'पाऊस (मिमी)',
        'soil_type': 'मातीचा प्रकार',
        'farm_size': 'शेतीचा आकार (एकर)',
        'get_recommendation': 'शिफारस मिळवा',
        
        # Soil Types
        'clayey': 'चिकण माती (Clayey)',
        'loamy': 'दोगड माती (Loamy)',
        'sandy': 'वाळूयुक्त माती (Sandy)',
        'black': 'काळी माती (Black Soil)',
        'red': 'लाल माती (Red Soil)',
        'alluvial': 'गाळाची माती (Alluvial)',
        
        # Recommendation Output
        'recommendation_result': 'शिफारस निकाल',
        'recommended_crop': 'शिफारस केलेले पीक',
        'confidence_score': 'विश्वासार्हता स्कोअर',
        'suitable_season': 'योग्य हंगाम',
        'crop_duration': 'पिकाचा कालावधी',
        'crop_desc': 'वर्णन',
        
        # Seeds
        'seed_details': 'शिफारस केलेल्या बियाण्यांच्या जाती',
        'variety_name': 'जातीचे नाव',
        'sowing_period': 'पेरणीचा कालावधी',
        'expected_yield': 'अपेक्षित उत्पन्न',
        'seed_qty': 'आवश्यक बियाणे प्रमाण',
        
        # Fertilizers
        'fertilizer_details': 'शिफारस केलेले खत वेळापत्रक',
        'nutrient_deficiency': 'पोषक तत्वांच्या कमतरतेची तपासणी',
        'recommended_fert': 'शिफारस केलेले खत',
        'fert_qty': 'वापरण्याचे प्रमाण',
        'fert_schedule': 'वापरण्याची वेळ',
        
        # Weather
        'weather_card': 'हवामान कार्ड',
        'wind_speed': 'वाऱ्याचा वेग',
        'forecast': 'पावसाचा अंदाज',
        'condition': 'हवामानाची स्थिती',
        'temp_current': 'सध्याचे तापमान',
        'humidity_current': 'सध्याची आर्द्रता',
        
        # Messages
        'login_success': 'यशस्वीरित्या लॉगिन केले!',
        'login_fail': 'अवैध ईमेल/मोबाईल किंवा पासवर्ड.',
        'reg_success': 'नोंदणी यशस्वी! कृपया लॉगिन करा.',
        'profile_update_success': 'प्रोफाईल यशस्वीरित्या अद्ययावत केली!',
        'reset_success': 'पासवर्ड यशस्वीरित्या रीसेट केला!',
        'access_denied': 'प्रवेश नाकारला. कृपया प्रथम लॉगिन करा.'
    }
}
